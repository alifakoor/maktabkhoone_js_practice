var showTodayDate = function() {
    alert('Hello')
}